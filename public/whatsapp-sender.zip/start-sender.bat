@echo off
set "ENV_FILE=%~1"
if "%ENV_FILE%"=="" set "ENV_FILE=.env"

title Masaar WhatsApp Sender - %ENV_FILE%
cd /d "%~dp0"

:: 1. Copy template .env if it does not exist (provides Supabase URLs prefilled)
if not exist "%ENV_FILE%" (
    if exist .env.example (
        copy .env.example "%ENV_FILE%" >nul
    )
)

:: 2. Check Node.js runtime environment
set "USE_LOCAL_NODE=0"
where node >nul 2>nul
if %errorlevel% neq 0 (
    if not exist "node\node.exe" (
        echo ==========================================================
        echo      Masaar WhatsApp Sender - Setup Runtime Engine
        echo ==========================================================
        echo.
        echo Node.js was not found on your system.
        echo Downloading portable Node.js runtime (one-time setup, please wait)...
        echo.
        
        powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://nodejs.org/dist/v20.11.1/node-v20.11.1-win-x64.zip' -OutFile 'node.zip'"
        
        if not exist node.zip (
            echo.
            echo Error: Failed to download Node.js runtime. Please check your internet connection.
            pause
            exit /b 1
        )
        
        echo Extracting runtime files...
        powershell -Command "Expand-Archive -Path 'node.zip' -DestinationPath 'node_temp' -Force"
        
        move node_temp\node-v20.11.1-win-x64 node >nul
        
        del node.zip
        rmdir /s /q node_temp
        
        echo Engine setup completed!
        echo.
    )
    set "USE_LOCAL_NODE=1"
)

:: 3. Configure Path if using local Node.js
if "%USE_LOCAL_NODE%"=="1" (
    set PATH=%CD%\node;%PATH%
)

:: 4. Run npm install if node_modules does not exist
if not exist node_modules (
    echo Installing required libraries (first run only, please wait)...
    call npm install --no-audit --no-fund
)

:loop
node sender.js "%ENV_FILE%"
echo.
echo Sender stopped. Restarting in 10 seconds... (close this window to stop)
timeout /t 10 >nul
goto loop

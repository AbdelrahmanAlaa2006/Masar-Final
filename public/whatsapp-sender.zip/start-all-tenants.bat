@echo off
cd /d "%~dp0"

echo =======================================================================
echo              Masaar WhatsApp Sender - Start All Tenants
echo =======================================================================
echo.
echo Scanning for tenant configuration files...
echo.

:: 1. Start default sender if .env exists
if exist .env (
    echo [v] Found default config: .env
    echo     Starting default sender...
    start "Masaar Sender - .env" cmd /c "start-sender.bat .env"
)

:: 2. Find and start all custom .env.* files (excluding .env.example)
setlocal enabledelayedexpansion
set "found_custom=0"
for %%f in (.env.*) do (
    if /i not "%%f"==".env.example" (
        set "found_custom=1"
        echo [v] Found tenant config: %%f
        echo     Starting sender for %%f...
        start "Masaar Sender - %%f" cmd /c "start-sender.bat %%f"
    )
)

if "!found_custom!"=="0" (
    echo.
    echo i Note: No custom tenant env files like .env.slug found.
    echo    If you want to run other tenants concurrently, copy .env.example
    echo    to .env.mona-chem or another tenant slug, configure it, and re-run this script.
)

echo.
echo =======================================================================
echo All senders have been launched in separate windows.
echo You can monitor each tenant's activity in its respective window.
echo =======================================================================
echo.
pause
